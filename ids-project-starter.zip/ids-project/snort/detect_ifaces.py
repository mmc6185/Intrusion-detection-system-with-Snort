# dummy iface detector
