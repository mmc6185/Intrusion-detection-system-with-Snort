#!/usr/bin/env python3
import psutil

active = [nic for nic, addrs in psutil.net_if_addrs().items()
          if any(a.family == 2 and not a.address.startswith('127.') for a in addrs)]

print('-i ' + ' -i '.join(active))
