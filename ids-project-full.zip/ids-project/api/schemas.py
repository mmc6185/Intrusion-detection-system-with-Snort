# Placeholder for future request/response schemas
