from flask import Flask, jsonify
from flask_cors import CORS
from sqlalchemy import create_engine, text
import os

app = Flask(__name__)
CORS(app)
engine = create_engine(os.getenv("DB_URL"))

@app.route("/stats")
def stats():
    with engine.connect() as c:
        res = c.execute(text("""
            SELECT severity, COUNT(*) AS cnt
            FROM alerts WHERE ts >= NOW() - INTERVAL 7 DAY
            GROUP BY severity
        """)).fetchall()
    return jsonify({r.severity: r.cnt for r in res})

@app.route("/alerts/latest")
def latest():
    with engine.connect() as c:
        rows = c.execute(text("""
            SELECT ts, src, dst, proto, sig, severity
            FROM alerts ORDER BY id DESC LIMIT 100
        """)).mappings().all()
    return jsonify(list(rows))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
