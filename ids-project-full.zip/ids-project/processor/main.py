import json, tailer, datetime, os, yaml
from sqlalchemy import create_engine, MetaData, Table

THRESHOLDS = yaml.safe_load(open(os.getenv("THRESHOLDS_FILE", "thresholds.yaml")))
SEVERITY = lambda p: THRESHOLDS.get(str(p), "safe")

engine = create_engine(os.getenv("DB_URL"))
meta = MetaData()
alerts = Table("alerts", meta, autoload_with=engine)

for line in tailer.follow(open("/logs/alert_json.txt")):
    ev = json.loads(line)
    sev = SEVERITY(ev.get("priority", 3))
    ins = alerts.insert().values(
        ts=datetime.datetime.fromtimestamp(ev["timestamp"]),
        src=ev["src_ip"], dst=ev["dst_ip"],
        proto=ev["proto"], sig=ev["signature"],
        severity=sev)
    with engine.begin() as conn:
        conn.execute(ins)
