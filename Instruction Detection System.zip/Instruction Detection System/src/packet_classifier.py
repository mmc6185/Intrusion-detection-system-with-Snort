import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Define known ports (example)
KNOWN_PORTS = {
    80: 'HTTP',
    443: 'HTTPS',
    22: 'SSH',
    23: 'Telnet',
    21: 'FTP',
    25: 'SMTP',
    110: 'POP3',
    143: 'IMAP',
    53: 'DNS',
    # Add more known ports as needed
}

# Define potentially risky ports or patterns
RISKY_PORTS = {23, 135, 137, 138, 139, 445} # Telnet, NetBIOS/SMB

class PacketClassifier:
    def __init__(self):
        # Initialize any state if needed (e.g., for stateful analysis)
        pass

    def classify_packet(self, packet_info: Dict[str, Any]) -> str:
        """
        Classify a packet based on its information.

        Args:
            packet_info: A dictionary containing analyzed packet data.

        Returns:
            A string indicating the classification: 'INFO', 'WARNING', 'ALARM', 'CRITICAL'.
        """
        
        # Default classification
        classification = 'INFO'

        src_port = packet_info.get('source_port')
        dst_port = packet_info.get('destination_port')
        protocol = packet_info.get('protocol')
        flags = packet_info.get('flags')

        # --- Simple Rule Examples --- 

        # Example: Risky ports -> WARNING
        if dst_port in RISKY_PORTS or src_port in RISKY_PORTS:
            classification = 'WARNING'
            logger.warning(f"Packet uses risky port: {dst_port or src_port}")
            return classification

        # Example: Telnet -> ALARM (usually unencrypted)
        if dst_port == 23 or src_port == 23:
            classification = 'ALARM'
            logger.warning(f"Telnet traffic detected: {packet_info}")
            return classification
            
        # Example: Null scan or Xmas scan -> ALARM
        if flags is not None: # Check if flags exist (TCP packet)
            # Convert hex flags (e.g., '0x000') to int if necessary
            try:
                flags_int = int(flags, 16) if isinstance(flags, str) else flags
                if flags_int == 0: # NULL Scan
                    classification = 'ALARM'
                    logger.warning(f"NULL Scan detected: {packet_info}")
                    return classification
                if flags_int == 0x029: # FIN, PSH, URG (Xmas Scan)
                    classification = 'ALARM'
                    logger.warning(f"Xmas Scan detected: {packet_info}")
                    return classification
            except (ValueError, TypeError) as e:
                logger.debug(f"Could not parse flags '{flags}': {e}")

        # Example: HTTP Error -> WARNING
        # (Requires deeper packet inspection, potentially adding response code to packet_info)
        # if packet_info.get('http_status_code', 200) >= 400:
        #     classification = 'WARNING'
        #     return classification

        # --- Add more complex rules here --- 
        # e.g., stateful analysis, signature matching, etc.

        # For now, default is INFO if no other rules match
        logger.debug(f"Packet classified as {classification}: {packet_info.get('source_ip')} -> {packet_info.get('destination_ip')}")
        return classification 