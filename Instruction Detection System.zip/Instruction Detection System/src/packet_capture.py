import os
import subprocess
import logging
from typing import Optional
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SnortCapture:
    def __init__(self):
        load_dotenv()
        self.snort_config = os.getenv('SNORT_CONFIG_PATH', '/etc/snort/snort.conf')
        self.interface = os.getenv('INTERFACE', 'eth0')
        self.snort_process: Optional[subprocess.Popen] = None

    def start_capture(self) -> bool:
        """
        Start Snort in packet capture mode
        Returns:
            bool: True if Snort started successfully, False otherwise
        """
        try:
            # Command to start Snort in packet capture mode
            cmd = [
                'snort',
                '-c', self.snort_config,
                '-i', self.interface,
                '-A', 'console',  # Alert mode
                '-l', './logs',   # Log directory
                '-K', 'pcap'      # Log packets in pcap format
            ]
            
            self.snort_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            logger.info(f"Snort started successfully on interface {self.interface}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start Snort: {str(e)}")
            return False

    def stop_capture(self):
        """Stop the Snort capture process"""
        if self.snort_process:
            self.snort_process.terminate()
            self.snort_process.wait()
            logger.info("Snort capture stopped")

    def get_capture_status(self) -> bool:
        """Check if Snort is currently capturing packets"""
        return self.snort_process is not None and self.snort_process.poll() is None

    def read_output(self) -> str:
        """
        Read the output from Snort process
        Returns:
            str: The output from Snort
        """
        if self.snort_process:
            try:
                output, _ = self.snort_process.communicate(timeout=1)
                return output
            except subprocess.TimeoutExpired:
                return ""
        return "" 