import pyshark
import logging
from typing import Dict, Any, Iterator, Tuple
from datetime import datetime
from packet_classifier import PacketClassifier

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PacketAnalyzer:
    def __init__(self, interface: str = None):
        self.interface = interface
        self.capture = None
        self.classifier = PacketClassifier()

    def start_live_capture(self, interface: str = None):
        """
        Start live packet capture on the specified interface
        Args:
            interface: Network interface to capture on
        """
        if interface:
            self.interface = interface

        if not self.interface:
            raise ValueError("No interface specified for packet capture")

        try:
            logger.info(f"Attempting to create LiveCapture on interface {self.interface}")
            
            # Try to create capture with explicit parameters
            self.capture = pyshark.LiveCapture(
                interface=self.interface,
                use_json=True,  # Use JSON output format which might be more stable
                include_raw=False,  # Don't include raw packet data to reduce complexity
                debug=True  # Enable debug output
            )
            
            # Verify the capture object
            if not self.capture:
                logger.error("LiveCapture creation failed - capture object is None")
                return False
                
            # Test the capture by attempting to get one packet
            logger.info("Testing capture by attempting to sniff one packet...")
            test_capture = list(self.capture.sniff_continuously(packet_count=1))
            if test_capture:
                logger.info("Successfully captured test packet")
            else:
                logger.warning("No test packet captured - interface might be inactive")
            
            logger.info(f"LiveCapture successfully initialized on interface {self.interface}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start live capture: {str(e)}")
            logger.error(f"Exception type: {type(e).__name__}")
            logger.error(f"Full exception details:", exc_info=True)
            self.capture = None
            return False

    def analyze_packet(self, packet) -> Dict[str, Any]:
        """
        Analyze a single packet and extract relevant information
        Args:
            packet: PyShark packet object
        Returns:
            Dict containing analyzed packet information or None if error
        """
        try:
            packet_info = {
                'timestamp': datetime.now().isoformat(),
                'source_ip': None,
                'destination_ip': None,
                'protocol': packet.highest_layer,
                'length': packet.length,
                'source_port': None,
                'destination_port': None,
                'flags': None,
                'http_method': None,
                'http_uri': None,
                'payload': None, # Consider adding payload data if needed for classification
            }

            if hasattr(packet, 'ip'):
                packet_info['source_ip'] = packet.ip.src
                packet_info['destination_ip'] = packet.ip.dst

            if hasattr(packet, 'tcp'):
                packet_info['source_port'] = packet.tcp.srcport
                packet_info['destination_port'] = packet.tcp.dstport
                packet_info['flags'] = packet.tcp.flags
                # Example: Accessing payload (raw data)
                # if hasattr(packet.tcp, 'payload'):
                #     packet_info['payload'] = packet.tcp.payload 

            elif hasattr(packet, 'udp'):
                packet_info['source_port'] = packet.udp.srcport
                packet_info['destination_port'] = packet.udp.dstport
                # if hasattr(packet.udp, 'payload'):
                #     packet_info['payload'] = packet.udp.payload

            if hasattr(packet, 'http'):
                if hasattr(packet.http, 'request_method'):
                    packet_info['http_method'] = packet.http.request_method
                if hasattr(packet.http, 'request_uri'):
                    packet_info['http_uri'] = packet.http.request_uri
                # Potentially add response code parsing here if analyzing server responses

            return packet_info

        except AttributeError as ae:
            # Handle cases where expected layers/fields are missing
            logger.debug(f"Packet missing expected attribute: {ae} in packet {packet.number}")
            return None # Return None or a minimal dict
        except Exception as e:
            logger.error(f"Error analyzing packet {packet.number}: {str(e)}")
            return None # Return None or a minimal dict

    def process_packets_live(self, packet_count: int = None) -> Iterator[Tuple[str, Dict[str, Any]]]:
        """
        Process captured packets, classify them, and yield results.
        Args:
            packet_count: Number of packets to process (None for unlimited).
        Yields:
            A tuple containing (classification, packet_info).
        """
        if not self.capture:
            raise RuntimeError("Capture not started. Call start_live_capture first.")

        logger.info("Starting continuous packet processing...")
        try:
            # sniff_continuously returns an iterator
            for packet in self.capture.sniff_continuously(packet_count=packet_count):
                analyzed_packet = self.analyze_packet(packet)
                
                if analyzed_packet: # Check if analysis was successful
                    classification = self.classifier.classify_packet(analyzed_packet)
                    # Add classification to the packet info itself
                    analyzed_packet['classification'] = classification 
                    yield classification, analyzed_packet
                else:
                    logger.debug(f"Skipping packet {packet.number} due to analysis error or missing data.")


        except KeyboardInterrupt:
            logger.info("Packet capture stopped by user (KeyboardInterrupt)")
        except Exception as e:
            # Log specific exceptions from pyshark if possible
            logger.error(f"Error during packet processing: {str(e)}", exc_info=True)
        finally:
            logger.info("Stopping packet capture process.")
            self.stop_capture()

    def stop_capture(self):
        """Stop the packet capture"""
        if self.capture:
            try:
                self.capture.close()
                logger.info("Packet capture closed")
            except Exception as e:
                logger.error(f"Error closing capture: {e}")
        self.capture = None 