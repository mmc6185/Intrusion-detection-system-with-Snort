import os
import logging
import threading
from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO, emit
from dotenv import load_dotenv
from packet_analyzer import PacketAnalyzer

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env')) # Adjust path if needed

# Initialize Flask app and SocketIO
app = Flask(__name__, template_folder='../templates', static_folder='../static')
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'your_secret_key') # Use env var for secret key
socketio = SocketIO(app, async_mode='threading') # Use threading for background task

# --- Global State --- 
packet_counts = {
    'INFO': 0,
    'WARNING': 0,
    'ALARM': 0,
    'CRITICAL': 0, # Placeholder for critical, classifier needs update
    'TOTAL': 0
}
# Store recent packets (optional, can grow large)
recent_packets = []
MAX_RECENT_PACKETS = 50 # Limit the list size

# Lock for thread safety when updating counts/packets
update_lock = threading.Lock()

# --- Background Packet Processing Thread --- 
packet_thread = None
stop_event = threading.Event()

def background_packet_processor():
    """Background thread function to capture and process packets."""
    logger.info("Background packet processor thread started.")
    
    interface = os.getenv('INTERFACE')
    if not interface:
        logger.error("Network interface not configured in .env file.")
        return

    analyzer = PacketAnalyzer(interface=interface)
    try:
        analyzer.start_live_capture()
        
        if not analyzer.capture:
            logger.error("Analyzer capture object was not initialized after start_live_capture. Aborting thread.")
            return
        
        logger.info("Live capture started successfully, proceeding to process packets.")
        for classification, packet_info in analyzer.process_packets_live():
            if stop_event.is_set():
                logger.info("Stop event received, stopping packet processing.")
                break
                
            with update_lock:
                packet_counts[classification] = packet_counts.get(classification, 0) + 1
                packet_counts['TOTAL'] += 1
                
                # Add to recent packets list (optional)
                recent_packets.insert(0, packet_info) # Add to beginning
                if len(recent_packets) > MAX_RECENT_PACKETS:
                    recent_packets.pop() # Remove oldest
                
            # Emit update to all connected clients
            socketio.emit('update_stats', {'counts': packet_counts})
            # Optionally emit the full packet if needed for a live feed
            # socketio.emit('new_packet', packet_info)
            
            # Small sleep to prevent overwhelming the system/clients if packet rate is extremely high
            socketio.sleep(0.01)
            
    except Exception as e:
        logger.error(f"Error in background packet processor: {e}", exc_info=True)
    finally:
        logger.info("Background packet processor thread finished.")
        analyzer.stop_capture() # Ensure capture is stopped

# --- Flask Routes --- 
@app.route('/')
def index():
    """Serve the main dashboard page."""
    return render_template('index.html')

@app.route('/api/stats')
def get_stats():
    """API endpoint to get current stats."""
    with update_lock:
        return jsonify(packet_counts)

@app.route('/api/packets')
def get_packets():
    """API endpoint to get recent packets (optional)."""
    with update_lock:
        return jsonify(recent_packets)

# --- SocketIO Events --- 
@socketio.on('connect')
def handle_connect():
    """Handle new client connection."""
    logger.info('Client connected')
    # Send initial stats to the newly connected client
    with update_lock:
        emit('update_stats', {'counts': packet_counts})
        
    # Start the background thread if it's not already running
    global packet_thread
    with update_lock:
        if packet_thread is None or not packet_thread.is_alive():
            logger.info('Starting background packet processing thread...')
            stop_event.clear()
            packet_thread = threading.Thread(target=background_packet_processor, daemon=True)
            packet_thread.start()
        else:
            logger.info('Background thread already running.')

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection."""
    logger.info('Client disconnected')
    # Consider stopping the background thread if no clients are connected?
    # Or let it run continuously.

# --- Main Execution (for direct run) --- 
if __name__ == '__main__':
    logger.info("Starting Flask-SocketIO server...")
    # Use host='0.0.0.0' to make it accessible on the network
    socketio.run(app, debug=True, host='0.0.0.0', port=5000, use_reloader=False)
    # use_reloader=False is important when using background threads
    # Cleanly stop the background thread on exit (though daemon=True helps)
    stop_event.set()
    if packet_thread:
        packet_thread.join(timeout=2) # Wait for thread to finish
    logger.info("Server stopped.") 