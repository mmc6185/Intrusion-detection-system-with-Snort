import os
import logging
import sys
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Make sure 'src' is in the Python path if running from the root directory
# This allows importing web_app
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# Import the app and socketio from web_app
try:
    from web_app import app, socketio, stop_event, packet_thread
except ImportError as e:
    logger.error(f"Failed to import web_app: {e}")
    logger.error("Ensure you are running this script from the project root or that src is in PYTHONPATH.")
    sys.exit(1)

def main():
    load_dotenv() # Load .env variables
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', 5000))
    debug_mode = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'

    logger.info(f"Starting Instruction Detection System Web UI...")
    logger.info(f"Server will run on http://{host}:{port}")

    try:
        # Run the Flask-SocketIO app
        # use_reloader=False is important to prevent the background thread
        # from starting multiple times in debug mode.
        socketio.run(app, host=host, port=port, debug=debug_mode, use_reloader=False)
        
    except KeyboardInterrupt:
        logger.info("Shutdown signal received (KeyboardInterrupt). Stopping...")
    except Exception as e:
        logger.error(f"An error occurred during server execution: {e}", exc_info=True)
    finally:
        logger.info("Attempting graceful shutdown...")
        # Signal the background thread to stop
        stop_event.set()
        # Wait for the thread to finish
        if packet_thread and packet_thread.is_alive():
            logger.info("Waiting for packet processing thread to complete...")
            packet_thread.join(timeout=5) # Add a timeout
            if packet_thread.is_alive():
                logger.warning("Packet processing thread did not exit cleanly.")
        logger.info("Instruction Detection System stopped.")

if __name__ == "__main__":
    main() 