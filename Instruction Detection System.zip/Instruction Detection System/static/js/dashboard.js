document.addEventListener('DOMContentLoaded', (event) => {
    // Connect to the Socket.IO server
    // Use window.location.origin for flexible deployment
    const socket = io.connect(window.location.origin);

    console.log('Attempting to connect to Socket.IO server...');

    socket.on('connect', () => {
        console.log('Successfully connected to Socket.IO server');
    });

    socket.on('disconnect', () => {
        console.log('Disconnected from Socket.IO server');
    });

    socket.on('connect_error', (err) => {
        console.error('Socket.IO connection error:', err);
    });

    // Listen for 'update_stats' events from the server
    socket.on('update_stats', (data) => {
        console.log('Received stats update:', data);
        const counts = data.counts;

        // Update main counter elements
        updateElementText('alarm-count', counts.ALARM || 0);
        updateElementText('critical-count', counts.CRITICAL || 0);
        updateElementText('warning-count', counts.WARNING || 0);
        updateElementText('info-count', counts.INFO || 0);

        // Update sidebar counter elements
        updateElementText('alarm-sidebar-count', counts.ALARM || 0);
        updateElementText('warning-sidebar-count', counts.WARNING || 0);
        updateElementText('info-sidebar-count', counts.INFO || 0);

        // Add potential animations or effects here if desired
    });

    // Helper function to update element text content
    function updateElementText(elementId, text) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = text;
        } else {
            console.warn(`Element with ID '${elementId}' not found.`);
        }
    }

    // --- Placeholder for future chart updates --- 
    // Example: if receiving chart data
    // socket.on('update_charts', (chartData) => { 
    //     // Update chart instances (e.g., using Chart.js) 
    // });
}); 