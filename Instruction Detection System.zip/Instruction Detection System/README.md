# Instruction Detection System

This project implements an instruction detection system that uses Snort for packet capture and Python for packet analysis.

## Prerequisites

- Python 3.8 or higher
- Snort (Network Intrusion Detection System)
- pip (Python package manager)

## Installation

1. Install Snort:
   ```bash
   # For macOS (using Homebrew)
   brew install snort
   
   # For Ubuntu/Debian
   sudo apt-get install snort
   ```

2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Configure Snort:
   - Edit the Snort configuration file (usually located at /etc/snort/snort.conf)
   - Make sure Snort has the necessary permissions to capture network traffic

## Project Structure

- `src/`: Contains the main Python source code
  - `packet_capture.py`: Handles packet capture using Snort
  - `packet_analyzer.py`: Analyzes captured packets
  - `main.py`: Main application entry point

## Usage

1. Start the application:
   ```bash
   python src/main.py
   ```

2. The system will:
   - Start Snort in packet capture mode
   - Analyze captured packets in real-time
   - Log suspicious activities and instructions

## Configuration

Create a `.env` file in the project root with the following variables:
```
SNORT_CONFIG_PATH=/path/to/snort.conf
INTERFACE=eth0  # or your network interface
``` 